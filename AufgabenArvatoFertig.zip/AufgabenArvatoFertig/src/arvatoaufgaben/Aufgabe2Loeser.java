/*
 * https://javaee.github.io/jsonp/
 * http://search.maven.org/remotecontent?filepath=javax/json/javax.json-api/1.0/javax.json-api-1.0.jar
 * http://www.java2s.com/Tutorials/Java/JSON/0100__JSON_Java.htm
 * ==> https://stackoverflow.com/questions/39786643/how-can-i-read-from-a-json-file-using-the-javax-json-package
 * http://repo1.maven.org/maven2/org/glassfish/javax.json/1.1/
 * https://stackoverflow.com/questions/48206431/parsing-and-reading-a-json-array-java
 */
package arvatoaufgaben;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.json.*;


/**
 *
 * @author danielmittring
 */
public class Aufgabe2Loeser
{
   static JsonArray productArray;
   static JsonReader reader;
   
   

   
   
    public static void main(String[] args) {
     
        String nameBilligstes="";
        double preisBilligstes=10000000; // schlecht
        String nameTeuerstes="";
        double preisTeuerstes=0;
        String nameMeistverkauft="";
        int    anzahlMeistverkauft=0;
        boolean fragilDabei = false;
        String dieserName;
        String diesesLand;
        double dieserPreis;
        boolean diesesZerbrechlich;
        int diesesWieOft;
        String deutscheProdukte="";
        String chinaProdukte="";
     
      try
       {  
        // da liegt die Datei im packageOrdner  
        InputStream fis = new FileInputStream("./src/arvatoaufgaben/sampleProductsData.json");
        // ein JSON-Reader, ein ausgelesenes Array von JSON-Objects aus der Datei
        reader = Json.createReader(fis);
        productArray = reader.readArray();
        // und wieder alles schließen
        reader.close(); 
       }catch (Exception e)
        {
           System.out.println(e);
        } 
      
        for (int zeile = 0; zeile < productArray.size(); zeile++)
        {
            JsonObject productObject = productArray.getJsonObject(zeile);
            // DIESES JSON-Objekt betrachten:
            System.out.println("Name            : " + productObject.getString("name"));
            dieserName = productObject.getString("name");
            System.out.println("Herkunftsland   : " + productObject.getString("countryOfOrigin"));
            diesesLand = productObject.getString("countryOfOrigin");
            System.out.println("Preis           : " + productObject.getJsonNumber("price"));
            dieserPreis = productObject.getJsonNumber("price").doubleValue();
            System.out.println("zerbrechlich    : " + productObject.getBoolean("isFragile"));
            diesesZerbrechlich = productObject.getBoolean("isFragile");
            System.out.println("wie oft bestellt: " + productObject.getInt("timesPurchased"));
            diesesWieOft = productObject.getInt("timesPurchased");
            System.out.println();
 
            //Dieses JSON-Objekt vergleichen
            if (dieserPreis > preisTeuerstes)    // finde das Teuerste
            {
               preisTeuerstes = dieserPreis;
               nameTeuerstes = dieserName;
            }
            
            if (dieserPreis < preisBilligstes)    // finde das Billigste
            {
               preisBilligstes = dieserPreis;
               nameBilligstes = dieserName;
            }  
            
            if (diesesWieOft > anzahlMeistverkauft)    // finde das begehrteste
            {
               anzahlMeistverkauft = diesesWieOft;
               nameMeistverkauft = dieserName;
            }
            
            if (diesesLand.equals("DE"))    // finde deutsche
            {
               deutscheProdukte = deutscheProdukte + "\n     \"" + dieserName + "\",";
               nameMeistverkauft = dieserName; // das letzte Komma ist zu viel
            }
            
            if (diesesLand.equals("CN"))    // finde chinesische
            {
               chinaProdukte = deutscheProdukte + "\n     \"" + dieserName + "\",";
               nameMeistverkauft = dieserName;
            }
            
            if (diesesZerbrechlich)    // finde mindestens ein zerbrechliches
            {
               fragilDabei = true;               
            }
     
        }
        
        // Ausgabe als String, muss noch in die JSON-Datei  
        String ergebnis = "{ \n   \"mostExpensiveProduct\": \""+ nameTeuerstes + "\",\n";
        ergebnis = ergebnis + "   \"cheapestProduct\": \""+ nameBilligstes + "\",\n";
        ergebnis = ergebnis + "   \"mostPopularProduct\": \""+ nameMeistverkauft + "\",\n";
        ergebnis = ergebnis + "   \"germanProducts\":  ["+ deutscheProdukte + "\n   ],\n";
        ergebnis = ergebnis + "   \"chineseProducts\":  ["+ chinaProdukte +   "\n   ],\n";
        ergebnis = ergebnis + "   \"containsFragileProducts\": \""+ fragilDabei + "\"\n }";
        
        System.out.println (ergebnis);
    }
}


