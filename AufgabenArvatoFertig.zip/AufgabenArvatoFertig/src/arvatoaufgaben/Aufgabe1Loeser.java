/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arvatoaufgaben;

/**
 *
 * @author danielmittring
 */
public class Aufgabe1Loeser {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Aufgabe 1
        ListenVergleicher Vergleicher = new ListenVergleicher();
        /* 
        System.out.println("Beide Ausgangs-Dateien werden eingelesen");
        Vergleicher.zweiListenEinlesen("./src/arvatoaufgaben/Liste1.txt" , "./src/arvatoaufgaben/Liste2.txt");
        System.out.println("Nur in der ersten:");
        Vergleicher.werIstNurInEins();
        
        Vergleicher.zweiListenEinlesen("./src/arvatoaufgaben/Liste1.txt" , "./src/arvatoaufgaben/Liste2.txt");
        System.out.println("Nur in der zweiten:");
        Vergleicher.werIstNurInZwei();
        
        Vergleicher.zweiListenEinlesen("./src/arvatoaufgaben/Liste1.txt" , "./src/arvatoaufgaben/Liste2.txt");
        System.out.println("In beiden:");
        Vergleicher.werIstInBeiden();
        */
        
        Vergleicher.listenVergleichenJSON();
        
    }
    
}
