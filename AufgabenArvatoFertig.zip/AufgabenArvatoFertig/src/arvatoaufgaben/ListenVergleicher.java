
package arvatoaufgaben;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.ListIterator;
/**
 * Quellen
 * https://www.informatikzentrale.de/java-arraylist.html
 * https://howtodoinjava.com/java/collections/arraylist/compare-two-arraylists/
 * @author danielmittring
 */
public class ListenVergleicher 
{
    ArrayList<String> Datei1 = new ArrayList<String>();
    ArrayList<String> Datei2 = new ArrayList<String>();
    ArrayList<String> nur1   = new ArrayList<String>();
    ArrayList<String> nur2   = new ArrayList<String>();
    ArrayList<String> beide  = new ArrayList<String>();
    
  public void zweiListenEinlesen(String dateiname1, String dateiname2)
   {
    Datei1.clear();
    Datei2.clear();
    try       // Die erste Datei als ArrayList Datei1 speichern
    {      
        File datei = new File(dateiname1); 
        BufferedReader leser1 = new BufferedReader(new FileReader(datei)); 
        String zeile = leser1.readLine();
        while(zeile != null) 
        {
            Datei1.add(zeile);
            zeile = leser1.readLine();
        }
      //System.out.println(dateiname1 + ": " + Datei1.size());  
    }
    catch(Exception e)
    {
        System.out.println("Fehler: " + e);
    }
    
    try
    {      
        File anderedatei = new File(dateiname2); 
        BufferedReader leser2 = new BufferedReader(new FileReader(anderedatei)); 
        String zeile = leser2.readLine();
        while(zeile != null) 
        {
            Datei2.add(zeile);
            zeile = leser2.readLine();
        }
      //System.out.println(dateiname2 + ": " + Datei2.size());  
    }
    catch(Exception e)
    {
        System.out.println("Fehler: " + e);
    }
   //System.out.println();
   //System.out.println("1vollständig: " + Datei1); // schauen, dass beide Listen da sind
   //System.out.println("2vollständig: " + Datei2);
  }
    
  public void werIstNurInEins()
  {
     Datei1.removeAll(Datei2);
     System.out.println(Datei1);
  }
  
  public void werIstNurInZwei()
  {
     Datei2.removeAll(Datei1);
     System.out.println(Datei2);
  }
  
  public void werIstInBeiden()
  {
     Datei1.retainAll(Datei2);
     System.out.println(Datei1);
  }
  
  public void listenVergleichenJSON()
  {   // per Hand, dafür gibt es sicher elegantere Libraries
      System.out.println("{");
      System.out.println("   \"onlyInList1\": [");
      this.zweiListenEinlesen("./src/arvatoaufgaben/Liste1.txt" , "./src/arvatoaufgaben/Liste2.txt");
      Datei1.removeAll(Datei2);
      ListIterator<String> li = Datei1.listIterator();
      while(li.hasNext())
      {
          System.out.print("   \"" + li.next() + "\"");
          if (li.hasNext())
              System.out.print(",");
          System.out.println();
      }
      System.out.println("   ],");
      
      System.out.println("   \"onlyInList2\": [");
      this.zweiListenEinlesen("./src/arvatoaufgaben/Liste1.txt" , "./src/arvatoaufgaben/Liste2.txt");
      Datei2.removeAll(Datei1);
      ListIterator<String> li2 = Datei2.listIterator();
      while(li2.hasNext())
      {
          System.out.print("     \"" + li2.next() + "\"");
          if (li2.hasNext())
              System.out.print(",");
          System.out.println();
      }
      System.out.println("   ],");
      
      System.out.println("   \"in both Lists\": [");
      this.zweiListenEinlesen("./src/arvatoaufgaben/Liste1.txt" , "./src/arvatoaufgaben/Liste2.txt");
      Datei1.retainAll(Datei2);
      ListIterator<String> li3 = Datei1.listIterator();
      while(li3.hasNext())
      {
          System.out.print("     \"" + li3.next() + "\"");
          if (li3.hasNext())
              System.out.print(",");
          System.out.println();
      }
      
      System.out.println("   ],");
      System.out.println("}");
      
  }   
}

